/*
 * Company
 * 2016  * 
 */
package com.company.model.dao;

import com.company.model.Usuario;
import java.util.List;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public interface UsuarioDao {

    Usuario findByUserName(String username);

    void save(Usuario usuario);
    
    void update(Usuario usuario);
    
    void delete(Usuario usuario);
    
    public List<Usuario> getUsuarios();

}
