/*
 * Company
 * 2016  * 
 */
package com.company.model.dao.impl;

import com.company.model.Perfil;
import com.company.model.dao.BaseDao;
import com.company.model.dao.PerfilDao;
import java.math.BigDecimal;
import java.util.ArrayList;
import java.util.List;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@Repository("perfilDao")
public class PerfilDaoImpl extends BaseDao implements PerfilDao {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Transactional
    public void save(Perfil perfil) {
        getSession().save(perfil);
    }

    public Perfil getById(int perfilId) {
        return getSession().get(Perfil.class,new BigDecimal(perfilId));
    }

    @Transactional
    public void update(Perfil perfil) {
        getSession().update(perfil);
    }

    @Transactional
    public void delete(Perfil perfil) {
        getSession().delete(perfil);
    }

    @SuppressWarnings("unchecked")
    public List<Perfil> findAll() {

        List<Perfil> perfiles = new ArrayList<Perfil>();
        perfiles = getSession().createQuery("from Perfil order by 1").list();

        if (perfiles.size() > 0) {
            return perfiles;
        } else {
            return null;
        }

    }

}
