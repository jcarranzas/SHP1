/*
 * Company
 * 2016  * 
 */
package com.company.model.util;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public enum Estado {

	INACTIVE(0),
	ACTIVE(1),
	LOCKED(2),
	DELETED(3);

    private int estado;

    private Estado(final int estado) {
        this.estado = estado;
    }

    public int getEstado() {
        return this.estado;
    }

    @Override
    public String toString() {
        return Integer.toString(this.estado);
    }

    public String getNombre() {
        return this.name();
    }

}
