/*
 * Company
 * 2016  * 
 */
package com.company.model.dao.impl;

import com.company.model.Menu;
import com.company.model.dao.BaseDao;
import com.company.model.dao.MenuDao;
import java.util.ArrayList;
import java.util.List;
import org.hibernate.Query;
import org.springframework.stereotype.Repository;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@Repository("MenuDao")
public class MenuDaoImpl extends BaseDao implements MenuDao {

    @Transactional
    public void guardar(Menu menu) {
        try {
            getSession().save(menu);
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
        }
    }

    @Transactional
    public void editar(Menu menu) {
        try {
            getSession().update(menu);
        } catch (Exception e) {
        } finally {
        }
    }

    @Transactional
    public void eliminar(Menu menu) {
        try {
            getSession().delete(menu);
        } catch (Exception e) {
        } finally {
        }
    }

    public Menu getById(long menuId) {
        return getSession().get(Menu.class, menuId);
    }

    @SuppressWarnings({"unchecked", "finally"})
    public List<Menu> buscarPorTipo(String tipo)
            throws Exception {
        List<Menu> lista = null;
        try {
            String sql = "from Menu m"
                    + " where m.tipo like :tipo";
            Query consulta = getSession().createQuery(sql);
            consulta.setString("tipo", tipo);
            lista = consulta.list();
        } catch (Exception e) {
        } finally {
            return lista;
        }
    }

    @SuppressWarnings({"unchecked", "finally"})
    public List<Menu> findItems(String tipo, long id)
            throws Exception {
        List<Menu> lista = null;
        try {
            String sql = "FROM Menu m"
                    + " WHERE m.tipo like :tipo AND m.submenu.menuId = :id";
            Query consulta = getSession().createQuery(sql);
            consulta.setString("tipo", tipo);
            consulta.setLong("id", id);
            lista = consulta.list();
        } catch (Exception e) {
            e.printStackTrace();
        } finally {
            return lista;
        }
    }

    @SuppressWarnings({"unchecked", "finally"})
    public List<Menu> findAll()
            throws Exception {

        List<Menu> menuList = new ArrayList<Menu>();
        menuList = getSession().createQuery("from Menu order by 1").list();

        if (menuList.size() > 0) {
            return menuList;
        } else {
            return null;
        }
    }

    @SuppressWarnings({"unchecked", "finally"})
    public List<Menu> findByState(boolean state)
            throws Exception {

        List<Menu> menuList = new ArrayList<Menu>();       
        Query consulta = getSession().createQuery("FROM Menu WHERE estado = :state order by 1");
        consulta.setBoolean("state", state);
        menuList = consulta.list();

        if (menuList.size() > 0) {
            return menuList;
        } else {
            return null;
        }
    }

}
