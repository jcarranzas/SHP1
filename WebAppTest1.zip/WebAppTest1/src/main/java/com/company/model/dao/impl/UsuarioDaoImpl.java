/*
 * Company
 * 2016  * 
 */
package com.company.model.dao.impl;

import com.company.model.Usuario;
import com.company.model.dao.BaseDao;
import com.company.model.dao.UsuarioDao;
import java.util.ArrayList;
import java.util.List;
import org.springframework.stereotype.Repository;
import org.hibernate.Criteria;
import org.hibernate.criterion.Restrictions;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@Repository("usuarioDao")
public class UsuarioDaoImpl extends BaseDao implements UsuarioDao {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Transactional
    public void save(Usuario usuario) {
        getSession().save(usuario);
    }
    
    @Transactional
    public void update(Usuario usuario) {
        getSession().update(usuario);
    }
    
    @Transactional
    public void delete(Usuario usuario) {
        getSession().delete(usuario);

    }

    public Usuario findByUserName(String username) {

        Criteria crit = getSession().createCriteria(Usuario.class);
        crit.add(Restrictions.eq("nombreUsuario", username));
        return (Usuario) crit.uniqueResult();

    }

    public List<Usuario> getUsuarios() {

        List<Usuario> usuarios = new ArrayList<Usuario>();
        usuarios = getSession().createQuery("from Usuario order by 2").list();

        if (usuarios.size() > 0) {
            return usuarios;
        } else {
            return null;
        }

    }

}
