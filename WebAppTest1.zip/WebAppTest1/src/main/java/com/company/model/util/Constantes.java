/*
 * Company
 * 2016  * 
 */
package com.company.model.util;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public interface Constantes {
    
    //TABLA MENU - CAMPO TIPO
    final static String MENU_TIPO_ITEM="I";
    final static String MENU_TIPO_SUBMENU="S";
    
    //TABLA MENU - CAMPO ESTADO
    final static boolean MENU_ESTADO_ACTIVO=true;
    final static boolean MENU_ESTADO_INACTIVO=false;
    
    //TABLA USUARIOS - CAMPO ESTADO
    final static int USUARIO_INACTIVO=0;
    final static int USUARIO_ACTIVO=1;
    final static int USUARIO_BLOQUEADO=2;
    final static int USUARIO_ELIMINADO=3;
    
}
