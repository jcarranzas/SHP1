/*
 * Company
 * 2016  * 
 */
package com.company.model;

import java.io.Serializable;
import java.math.BigDecimal;
import javax.persistence.Basic;
import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.SequenceGenerator;
import javax.persistence.Table;
import javax.validation.constraints.NotNull;
import javax.validation.constraints.Size;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@Entity
@Table(name = "WEBAPP_PERFIL")
public class Perfil implements Serializable {

    private static final long serialVersionUID = 1L;

    @Id
    @Column(name = "PERFIL_ID")
    @GeneratedValue(strategy=GenerationType.SEQUENCE, generator="SEQ_WEBAPP_PERFIL")
    @SequenceGenerator(name="SEQ_WEBAPP_PERFIL", sequenceName = "SEQ_WEBAPP_PERFIL" ,allocationSize = 1)
    private BigDecimal perfilId;

    @Basic(optional = false)
    @NotNull
    @Size(min = 1, max = 50)
    @Column(name = "NOMBRE_PERFIL")
    private String nombrePerfil;
    
    public Perfil() {
    }

    public Perfil(BigDecimal perfilId) {
        this.perfilId = perfilId;
    }

    public Perfil(BigDecimal perfilId, String nombrePerfil) {
        this.perfilId = perfilId;
        this.nombrePerfil = nombrePerfil;
    }

    public BigDecimal getPerfilId() {
        return perfilId;
    }

    public void setPerfilId(BigDecimal perfilId) {
        this.perfilId = perfilId;
    }

    public String getNombrePerfil() {
        return nombrePerfil;
    }

    public void setNombrePerfil(String nombrePerfil) {
        this.nombrePerfil = nombrePerfil;
    }

    @Override
    public String toString() {
        return "com.company.model.Perfil[ perfilId=" + perfilId + " ]";
    }

}
