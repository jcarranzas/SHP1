/*
 * Company
 * 2016  * 
 */
package com.company.model.util;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public enum TipoMenu {

    SUBMENU("S"),
    ITEM("I");
    
    private TipoMenu(String tipoMenu ){
        this.tipoMenu = tipoMenu;
    }

    private String tipoMenu;

    /**
     * @return the tipoMenu
     */
    public String getTipoMenu() {
        return tipoMenu;
    }

}
