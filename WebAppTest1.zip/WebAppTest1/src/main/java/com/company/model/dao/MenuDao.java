/*
 * Company
 * 2016  * 
 */
package com.company.model.dao;

import com.company.model.Menu;
import java.util.List;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public interface MenuDao {

    void guardar(Menu menu);

    void editar(Menu menu);

    void eliminar(Menu menu);

    public Menu getById(long menuId);

    List<Menu> buscarPorTipo(String tipo)
            throws Exception;

    List<Menu> findAll()
            throws Exception;

    List<Menu> findByState(boolean state)
            throws Exception;

    List<Menu> findItems(String tipo, long id)
            throws Exception;

}
