/*
 * Company
 * 2016  * 
 */
package com.company.model.util;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public enum TipoPerfil {
    USER("USER"),
    DBA("DBA"),
    ADMIN("ADMIN");

    String tipoPerfil;

    private TipoPerfil(final String tipoPerfil) {
        this.tipoPerfil = tipoPerfil;
    }

    /**
     * @return the tipoPerfil
     */
    public String getTipoPerfil() {
        return tipoPerfil;
    }

    /**
     * @param tipoPerfil the tipoPerfil to set
     */
    private void setTipoPerfil(String tipoPerfil) {
        this.tipoPerfil = tipoPerfil;
    }

}
