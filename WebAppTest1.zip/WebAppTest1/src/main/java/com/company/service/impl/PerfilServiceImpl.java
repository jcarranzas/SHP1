/*
 * Company
 * 2016  * 
 */
package com.company.service.impl;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
import com.company.model.Perfil;
import com.company.model.dao.PerfilDao;
import com.company.service.PerfilService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

@Service("perfilService")
@Transactional
public class PerfilServiceImpl implements PerfilService {

    @Autowired
    PerfilDao dao;

    public void save(Perfil perfil) {
        dao.save(perfil);
    }

    public void update(Perfil perfil) {
        dao.update(perfil);
    }

    public void delete(Perfil perfil) {
        dao.delete(perfil);
    }

    public List<Perfil> findAll() {
        return dao.findAll();
    }

    public Perfil getById(int perfilId) {
        return dao.getById(perfilId);
    }

}
