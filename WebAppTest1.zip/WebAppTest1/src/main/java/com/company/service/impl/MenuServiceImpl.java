/*
 * Company
 * 2016  * 
 */
package com.company.service.impl;

import com.company.model.Menu;
import com.company.model.dao.MenuDao;
import com.company.service.MenuService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@Service("menuService")
@Transactional
public class MenuServiceImpl implements MenuService {

    @Autowired
    MenuDao dao;

    public void guardar(Menu menu) {
        dao.guardar(menu);
    }

    public void editar(Menu menu) {
        dao.editar(menu);
    }

    public void eliminar(Menu menu) {
        dao.eliminar(menu);
    }

    public Menu getById(long menuId) {
        return dao.getById(menuId);
    }

    public List<Menu> buscarPorTipo(String tipo)
            throws Exception {
        return dao.buscarPorTipo(tipo);
    }

    public List<Menu> findAll()
            throws Exception {
        return dao.findAll();
    }

    public List<Menu> findByState(boolean state) throws Exception {
        return dao.findByState(state);
    }

    public List<Menu> findItems(String tipo, long id)
            throws Exception {
        return dao.findItems(tipo, id);
    }

}
