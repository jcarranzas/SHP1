/*
 * Company
 * 2016  * 
 */
package com.company.service;

import com.company.model.Usuario;
import java.util.List;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public interface UsuarioService {

    void save(Usuario usuario);

    void update(Usuario usuario);

    void delete(Usuario usuario);

    Usuario findByUserName(String username);

    public List<Usuario> getUsuarios();

}
