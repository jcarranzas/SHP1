/*
 * Company
 * 2016  * 
 */
package com.company.service.impl;

import com.company.model.Usuario;
import com.company.model.dao.UsuarioDao;
import com.company.service.UsuarioService;
import java.util.List;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.crypto.password.PasswordEncoder;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@Service("usuarioService")
@Transactional
public class UsuarioServiceImpl implements UsuarioService {

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @Autowired
    private UsuarioDao dao;

    @Autowired
    private PasswordEncoder passwordEncoder;

    public void save(Usuario usuario) {
        usuario.setContrasena(passwordEncoder.encode(usuario.getContrasena()));
        dao.save(usuario);
    }

    public void update(Usuario usuario) {
        dao.update(usuario);
    }

    public void delete(Usuario usuario) {
        dao.delete(usuario);
    }

    public Usuario findByUserName(String username) {
        logger.info("username: " + username);
        return dao.findByUserName(username);
    }

    public List<Usuario> getUsuarios() {
        return dao.getUsuarios();
    }

}
