/*
 * Company
 * 2016  * 
 */
package com.company.service;

import com.company.model.Perfil;
import java.util.List;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public interface PerfilService {

    void save(Perfil perfil);

    void update(Perfil perfil);

    void delete(Perfil perfil);

    public Perfil getById(int perfilId);

    List<Perfil> findAll();

}
