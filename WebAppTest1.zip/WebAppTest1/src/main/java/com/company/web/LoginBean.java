/*
 * Company
 * 2016  * 
 */
package com.company.web;

import com.company.model.Menu;
import com.company.model.Usuario;
import com.company.model.util.Constantes;
import com.company.service.MenuService;
import com.company.service.UsuarioService;
import com.company.web.util.FacesUtils;
import com.company.web.util.LoginUtils;
import java.io.Serializable;
import java.util.Collection;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.SessionScoped;
import javax.faces.context.FacesContext;
import org.primefaces.model.menu.DefaultMenuItem;
import org.primefaces.model.menu.DefaultMenuModel;
import org.primefaces.model.menu.DefaultSubMenu;
import org.primefaces.model.menu.MenuModel;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.security.core.Authentication;
import org.springframework.security.core.GrantedAuthority;
import org.springframework.security.core.context.SecurityContextHolder;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@ManagedBean
@SessionScoped
//@RequestScoped // no envia las variables por session y no se ve el admin en el menu
public class LoginBean implements Serializable {

    private static final long serialVersionUID = -5354249232588110131L;
    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @ManagedProperty(value = "#{usuarioService}")
    private UsuarioService usuarioService;
    private Usuario usuario;
    private String actual;
    private String nueva;
    private String confirmar;

    @ManagedProperty(value = "#{menuService}")
    private MenuService menuService;
    private List<Menu> lista = null;
    private List<Menu> listaMP = null;
    private MenuModel model;

    @PostConstruct
    public void init() {
        usuario = new Usuario();
        actual = "";
        nueva = "";
        confirmar = "";
    }

    public LoginBean() {

    }

    public String getActual() {
        return actual;
    }

    public void setActual(String actual) {
        this.actual = actual;
    }

    public String getNueva() {
        return nueva;
    }

    public void setNueva(String nueva) {
        this.nueva = nueva;
    }

    public String getConfirmar() {
        return confirmar;
    }

    public void setConfirmar(String confirmar) {
        this.confirmar = confirmar;
    }

    public void setUsuarioService(UsuarioService usuarioService) {
        this.usuarioService = usuarioService;
    }

    public Usuario getUsuario() {
        Authentication auth = SecurityContextHolder.getContext().getAuthentication();
        /*Collection<GrantedAuthority> authorities = (Collection<GrantedAuthority>) auth.getAuthorities();
        String role = ((GrantedAuthority) authorities.iterator().next()).getAuthority();
        String roleSplited = role.substring(5);
        logger.info("Roles: " + roleSplited);*/
        usuario = usuarioService.findByUserName(auth.getName());
        return this.usuario;
    }

    public void setUsuario(Usuario usuario) {
        this.usuario = usuario;
    }

    public void cambiar() {

        String abd = "";
        if (usuario != null && usuario.getContrasena() != null) {
            abd = usuario.getContrasena();
        }
        logger.info("UsuarioId: " + usuario.getUsuarioId() + " ContraseñaActual: " + actual);

        if (actual.isEmpty() || nueva.isEmpty() || confirmar.isEmpty()) {
            FacesUtils.showFacesMessage("No dejar campos vacios", 3);
        } else if (!LoginUtils.matchesPassword(actual, abd)) {
            FacesUtils.showFacesMessage("La contraseña actual es incorrecta", 3);
        } else if (!nueva.equals(confirmar)) {
            FacesUtils.showFacesMessage("La confirmacion es incorrecta", 3);
        } else {
            usuario.setContrasena(LoginUtils.encodePassword(confirmar));
            usuarioService.update(usuario);
            FacesUtils.showFacesMessage("Contraseña cambiada", 3);
        }
    }

    public String salir() {
        SecurityContextHolder.clearContext();
        return "pretty:login";
    }

    public void listarMP() {
        try {
            setListaMP(menuService.findByState(Constantes.MENU_ESTADO_ACTIVO));
        } catch (Exception e) {
        }
    }

    public void listarMenus() {
        try {
            setLista(menuService.findAll());
        } catch (Exception e) {
        }
    }

    public List<Menu> getLista() {
        return lista;
    }

    public void setLista(List<Menu> lista) {
        this.lista = lista;
    }

    public List<Menu> getListaMP() {
        return listaMP;
    }

    public void setListaMP(List<Menu> listaMP) {
        this.listaMP = listaMP;
    }

    public void establecerPermisos() {

        model = new DefaultMenuModel();
        logger.info("UsuarioId: " + usuario.getUsuarioId() + " NombrePerfil(Usuario): " + usuario.getPerfil().getNombrePerfil());

        for (Menu m : listaMP) {
            logger.info("UsuarioId: " + usuario.getUsuarioId() + " Perfil(Menu): " + m.getPerfil().getNombrePerfil());
            if (m.getTipo().equals(Constantes.MENU_TIPO_SUBMENU) && m.getPerfil().getNombrePerfil().equals(usuario.getPerfil().getNombrePerfil())) {
                DefaultSubMenu firstSubmenu = new DefaultSubMenu(m.getNombre());
                firstSubmenu.setIcon(m.getIcon());
                logger.info("UsuarioId: " + usuario.getUsuarioId() + " Nombre(Menu) TIPO S: " + m.getNombre());
                for (Menu i : listaMP) {
                    Menu submenu = i.getSubmenu();
                    if (submenu != null) {
                        if (submenu.getMenuId() == m.getMenuId()) {
                            logger.info("UsuarioId: " + usuario.getUsuarioId() + " Nombre Item(Menu): " + i.getNombre());
                            DefaultMenuItem item = new DefaultMenuItem(i.getNombre());
                            item.setUrl(i.getUrl());
                            item.setIcon(null);
                            firstSubmenu.addElement(item);
                        }
                    }
                }
                model.addElement(firstSubmenu);
            } else if (m.getSubmenu() == null && m.getPerfil().getNombrePerfil().equals(usuario.getPerfil().getNombrePerfil())) {
                logger.info("UsuarioId: " + usuario.getUsuarioId() + " Nombre(Menu) TIPO I: " + m.getNombre());
                DefaultMenuItem item = new DefaultMenuItem(m.getNombre());
                item.setUrl(m.getUrl());
                item.setIcon(m.getIcon());
                model.addElement(item);
            }
        }
        model.generateUniqueIds();
    }

    public MenuModel getModel() {
        getUsuario();
        listarMenus();
        listarMP();
        this.establecerPermisos();
        return model;
    }

    public void setModel(MenuModel model) {
        this.model = model;
    }

    public void setMenuService(MenuService menuService) {
        this.menuService = menuService;
    }

}
