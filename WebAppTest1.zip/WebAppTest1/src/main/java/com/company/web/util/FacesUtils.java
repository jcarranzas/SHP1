/*
 * Company
 * 2016  * 
 */
package com.company.web.util;


import javax.faces.application.FacesMessage;
import javax.faces.context.FacesContext;


/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
public class FacesUtils {
    
  
    public static void showFacesMessage(String texto, int tipo) {
        switch (tipo) {
            case 1:
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_ERROR, texto, "Error"));
                break;
            case 2:
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_FATAL, texto, "Fatal"));
                break;
            case 3:
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_INFO, texto, "Aviso"));
                break;
            case 4:
                FacesContext.getCurrentInstance().addMessage(null, new FacesMessage(FacesMessage.SEVERITY_WARN, texto, "Advertencia"));
                break;
        }
    }
    
}
