/*
 * Company
 * 2016  * 
 */
package com.company.web;

import com.company.model.Perfil;
import com.company.service.PerfilService;
import com.company.web.util.FacesUtils;
import java.io.Serializable;
import java.util.List;
import javax.annotation.PostConstruct;
import javax.faces.bean.ManagedBean;
import javax.faces.bean.ManagedProperty;
import javax.faces.bean.ViewScoped;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;

/**
 *
 * @author Jhon Carranza Silva <jcarranzas@outlook.com>
 */
@ManagedBean
@ViewScoped
public class PerfilBean implements Serializable {

    private static final long serialVersionUID = 2611341912105487634L;

    protected final Logger logger = LoggerFactory.getLogger(this.getClass());

    @ManagedProperty(value = "#{perfilService}")
    private PerfilService perfilService;
    private List<Perfil> perfiles;
    private Perfil perfil;

    @PostConstruct
    public void init() {
        perfiles = perfilService.findAll();
    }

    public List<Perfil> getPerfiles() {
        return perfiles;
    }

    public void setPerfilService(PerfilService perfilService) {
        this.perfilService = perfilService;
    }

    /**
     * @return the perfil
     */
    public Perfil getPerfil() {
        return perfil;
    }

    /**
     * @param perfil the perfil to set
     */
    public void setPerfil(Perfil perfil) {
        this.perfil = perfil;
    }

    public void nuevo() {
        perfil = new Perfil();
    }

    public void guardar() {

        logger.info(" Update PerfilId: " + perfil.getPerfilId().intValue() + " nombrePerfil:" + perfil.getNombrePerfil());
        try {
            perfilService.update(perfil);
            FacesUtils.showFacesMessage("Perfil guardado.", 3);
            perfiles = perfilService.findAll();
        } catch (Exception e) {
            FacesUtils.showFacesMessage("Error: Perfil NO guardado.", 1);
            e.printStackTrace();
        }

    }

    public void insertar() {

        //logger.info(" Save PerfilId: " + perfil.getPerfilId().intValue() + " nombrePerfil:" + perfil.getNombrePerfil());

        try {
            perfilService.save(perfil);
            FacesUtils.showFacesMessage("Perfil nuevo guardado.", 3);
            perfiles = perfilService.findAll();
        } catch (Exception e) {
            FacesUtils.showFacesMessage("Error: Perfil nuevo NO guardado.", 1);
            e.printStackTrace();
        }

    }

    public void eliminar() {

        logger.info("PerfilId: " + perfil.getPerfilId().intValue() + " nombrePerfil:" + perfil.getNombrePerfil());

        try {
            perfilService.delete(perfil);
            FacesUtils.showFacesMessage("Perfil eliminado", 3);
            perfiles = perfilService.findAll();
        } catch (Exception e) {
            FacesUtils.showFacesMessage("Error: Perfil NO eliminado.", 1);
            e.printStackTrace();
        }

    }

}
